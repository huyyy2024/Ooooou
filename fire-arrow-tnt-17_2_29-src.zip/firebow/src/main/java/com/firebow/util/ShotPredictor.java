package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.util.math.Vec3d;

/**
 * Dự đoán điểm rơi của mũi tên NGAY LÚC THẢ CUNG, chưa có entity nào.
 *
 * Khớp với vanilla:
 *  - lực: BowItem.getPullProgress(useTicks) × 3.0, bắn khi pull ≥ 0.1
 *  - vị trí: eyePos − 0.1 theo Y
 *  - hướng: (−sin yaw·cos pitch, −sin pitch, cos yaw·cos pitch)
 *  - velocity kế thừa của người bắn: ngang luôn, dọc khi không đứng trên đất
 *    (đây là lý do bắn khi đang chạy thì điểm rơi lệch so với đứng yên)
 */
public final class ShotPredictor {
    private ShotPredictor() {}

    private static final int BOW_MAX_USE_TIME = 72000;

    public static ArrowLanding.Hit predictRelease(ClientPlayerEntity p, int useTimeLeft) {
        if (p.getWorld() == null) return null;

        // useTimeLeft là giá trị của tick cuối còn giương; lúc thả đã trôi thêm 1 tick
        int used = Math.max(0, BOW_MAX_USE_TIME - (useTimeLeft - 1));
        float pull = BowItem.getPullProgress(used);
        if (pull < 0.1f) return null;
        double speed = pull * 3.0;

        double yr = Math.toRadians(p.getYaw());
        double pr = Math.toRadians(p.getPitch());
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3d vel = dir.normalize().multiply(speed);

        Vec3d sv = p.getVelocity();
        vel = vel.add(sv.x, p.isOnGround() ? 0.0 : sv.y, sv.z);

        Vec3d pos = p.getEyePos().add(0.0, -0.1, 0.0);
        return ArrowLanding.predict(p.getWorld(), pos, vel, 120, p);
    }
}
