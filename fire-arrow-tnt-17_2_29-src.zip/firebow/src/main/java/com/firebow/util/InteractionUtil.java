package com.firebow.util;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v13 — silent rotation.
 *
 * Chỉ interact khi RotationUtil đang active (góc silent đã nằm trong movement packet của tick này).
 * Điểm hit là tâm mặt trên của block nền / rail, đúng với điểm đã arm.
 * Đổi slot chỉ đổi field phía client, vanilla sync khi interact.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    public enum Result { SENT, NOT_READY, INVALID }

    /**
     * true: vẫn đặt khi đang giữ chuột phải giương cung (lượt giương kế tiếp có thể bị hủy vì đổi slot).
     * Không ảnh hưởng mũi tên vừa thả: đó là việc đã xong trên server trước khi mod đụng slot.
     * false: chờ tới khi thả chuột phải.
     */
    public static final boolean ALLOW_PLACE_WHILE_DRAWING = true;

    private static boolean blocksByUse(ClientPlayerEntity p) {
        return !ALLOW_PLACE_WHILE_DRAWING && p.isUsingItem();
    }

    public static boolean railReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (blocksByUse(p) || !inReach(p, railPos))          return false;
        if (!mc.world.getBlockState(railPos).isAir())         return false;
        return PlacementCalc.isSolidGround(mc.world, railPos.down());
    }

    public static boolean cartReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (blocksByUse(p) || !inReach(p, railPos))          return false;
        var s = mc.world.getBlockState(railPos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }

    public static Result executeRail(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return Result.INVALID;

        BlockPos ground = railPos.down();
        if (!mc.world.getBlockState(railPos).isAir())       return Result.INVALID;
        if (!PlacementCalc.isSolidGround(mc.world, ground)) return Result.INVALID;
        if (!RotationUtil.isActive() || blocksByUse(p) || !inReach(p, railPos)) return Result.NOT_READY;

        Vec3d hitVec = RotationUtil.calcHitVec(ground, Direction.UP);
        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = railSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, ground, false));
        p.getInventory().selectedSlot = origSlot;
        return Result.SENT;
    }

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        if (!RotationUtil.isActive() || blocksByUse(p) || !inReach(p, railPos)) return false;

        Vec3d hitVec = RotationUtil.railHit(railPos);
        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;
        return true;
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
