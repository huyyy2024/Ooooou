package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.ArrowLanding;
import com.firebow.util.PlacementCalc;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Unique private int firebow$age = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        firebow$age++;
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        if (self.getVelocity().lengthSquared() < 0.0001) return;
        if (firebow$age > 60) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d pos   = self.getPos();
        Vec3d vel   = self.getVelocity();
        World world = self.getWorld();

        ArrowLanding.Hit hit = ArrowLanding.predict(world, pos, vel, 120, self.getOwner());
        if (hit == null || hit.ticks() > 40) return;
        BlockPos railPos = hit.cartBlock();

        Vec3d eye     = mc.player.getEyePos();
        Vec3d velP    = mc.player.getVelocity();
        double vy     = mc.player.isOnGround() ? velP.y : (velP.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(velP.x, vy, velP.z);
        Vec3d center  = Vec3d.ofCenter(railPos);

        double distCur  = eye.squaredDistanceTo(center);
        double distNext = eyeNext.squaredDistanceTo(center);
        if (Math.max(distCur, distNext) > 4.5 * 4.5) return;
        if (distNext < 1.0) return;

        // Có đủ rail + cart mới bắt đầu job
        if (PlacementTarget.tryCreate(railPos) == null) return;

        rt.requestRail(mc, entityId, railPos);
    }

    private boolean isOwnArrow(PersistentProjectileEntity a, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = a.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
