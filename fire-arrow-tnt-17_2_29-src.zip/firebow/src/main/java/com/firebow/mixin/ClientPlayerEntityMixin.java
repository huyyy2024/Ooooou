package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    private boolean firebow$wasUsingBow = false;
    private int     firebow$useTimeLeft = 0;

    /** HEAD tick: phát hiện thả cung để dự đoán điểm rơi. Không đổi slot, không gửi packet. */
    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$watchRelease(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        boolean usingBow = self.isUsingItem() && self.getActiveItem().isOf(Items.BOW);
        if (usingBow) {
            firebow$wasUsingBow = true;
            firebow$useTimeLeft = self.getItemUseTimeLeft();
        } else if (firebow$wasUsingBow) {
            firebow$wasUsingBow = false;
            FireBowRuntime.get().onBowReleased(self, firebow$useTimeLeft);
        }
    }

    /** HEAD tickMovement: arm góc trước khi input được đọc và velocity được tính. */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void firebow$beforeMovement(CallbackInfo ci) {
        FireBowRuntime.get().beforeMovement();
    }

}
